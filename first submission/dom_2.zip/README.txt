I misread the assignment and thought we needed to use arrow keys to move about. At the last minute I tried to get it working with buttons.
At this point it only works with arrow keys to move about cells.
